from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request, 'index.html')
def tem404(request):
    return render(request,'404.html')

def about(request):
    return render(request,'about.html')

def appoint(request):
    return render (request, 'appointment.html')

def call(request):
    return render(request,'call-to-action.html')

def clas(request):
    return render(request,'classes.html')
def contact(request):
    return render(request,'contact.html')
def fac(request):
    return render(request, 'facility.html')
def team(request):
    return render(request, 'team.html')
def test(request):
    return render(request,'testimonial.html')