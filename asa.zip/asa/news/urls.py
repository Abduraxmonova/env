from django.urls import path
from .views import index, tem404, about, appoint, call, clas, contact, fac, team, test
urlpatterns = [
    path('',index,name='i'),
    path("about",about, name='about'),
    path('clas',clas, name='clas'),
    path('app',appoint,name='app'),
    path('call', call,name='call'),
    path('contact',contact,name='contact'),
    path('t',tem404, name='t'),
    path('f',fac,name='f'),
    path('tm',team,name='tm'),
    path('ts',test, name='ts'),
]
